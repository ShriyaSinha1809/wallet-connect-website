<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="Main" tilewidth="64" tileheight="64" tilecount="247" columns="19">
 <image source="../assets/Terrain (64x64).png" width="1216" height="832"/>
</tileset>
