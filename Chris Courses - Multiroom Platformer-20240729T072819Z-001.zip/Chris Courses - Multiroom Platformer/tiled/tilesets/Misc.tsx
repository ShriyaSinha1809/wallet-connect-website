<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="Objects" tilewidth="92" tileheight="112" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="92" height="112" source="../assets/door.png"/>
 </tile>
 <tile id="1">
  <image width="44" height="32" source="../assets/box.png"/>
 </tile>
 <tile id="2">
  <image width="64" height="64" source="../assets/collision.png"/>
 </tile>
</tileset>
